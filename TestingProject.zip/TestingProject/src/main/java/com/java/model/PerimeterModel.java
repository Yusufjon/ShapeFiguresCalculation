package com.java.model;

public class PerimeterModel {

	
	
	private String calculation;
	private int a;
	private int b;
	
	
	public PerimeterModel() {
		
	}
	
	public String getCalculation() {
		return calculation;
	}
	public void setCalculation(String calculation) {
		this.calculation = calculation;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
