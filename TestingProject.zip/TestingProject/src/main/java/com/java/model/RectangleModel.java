package com.java.model;



public class RectangleModel {

	private int a;
	private int b;
	
	
	public RectangleModel() {
		
	}
	
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	
	
	
	
}
